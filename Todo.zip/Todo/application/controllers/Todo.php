<?php

class Todo extends CI_controller{
    function index(){
        $this->load->model('Todo_model');
        $todos = $this->Todo_model->getAllTodos();
        $data = array();
        $data['todos'] = $todos;
        $this->load->view('header.php');
        $this->load->view('list.php',$data);
        $this->load->view('footer.php');
    }

    function details($id){
        $this->load->model('Todo_model');
        $todo = $this->Todo_model->getTodo($id);
        $data = array();
        $data['todo'] = $todo;
        $this->load->view('header.php');
        $this->load->view('details.php', $data);
        $this->load->view('footer.php');
    }


    function create(){
        $this->load->model('Todo_model');
        $this->form_validation->set_rules('name','Name','required');
        $this->form_validation->set_rules('description', 'Description', 'required');

        if($this->form_validation->run() == false){
            $this->load->view('header');
            $this->load->view('create');
            $this->load->view('footer');
        }
        else{
            //save user to database
            $formArray = array();
            $formArray['name'] = $this->input->post('name');
            $formArray['description'] = $this->input->post('description');
          
            $this->Todo_model->create($formArray);
            $this->session->set_flashdata('success', 'Todo added successfully!');
            redirect(base_url().'todo/index');
        }
        
    
    }


    function edit($id){
        $this->load->model('Todo_model');
        $todo =  $this->Todo_model->getTodo($id);
        $data = array();
        $data['todo'] = $todo;


        $this->form_validation->set_rules('name','Name','required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        if($this->form_validation->run() == false){
            $this->load->view('header');
            $this->load->view('edit', $data);
            $this->load->view('footer');
        }
        else{
            //update user record
            $formArray = array();
            $formArray['name'] = $this->input->post('name');
            $formArray['description'] = $this->input->post('description');
           
            $this->Todo_model->editTodo($id,$formArray);
            $this->session->set_flashdata('success','Todo Updated Successfully');
            redirect(base_url().'todo/');
        }
    }

    function delete($id){
        $this->load->model('Todo_model');
        $todo = $this->Todo_model->getTodo($id);
        if(empty($todo)) {
            $this->session->set_flashdata('failure','Record not found in database');
            redirect(base_url().'todo/');
        }
        $this->Todo_model->deleteTodo($id);
        $this->session->set_flashdata('success','Record deleted successfully');
        redirect(base_url().'todo/');
    }


}




?>