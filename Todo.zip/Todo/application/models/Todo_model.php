<?php


    class Todo_model extends CI_model{
    
        function getAllTodos(){
            return $todos = $this->db->get('todos')->result_array();
        }
        
        function getTodo($id){
            $this->db->where('id',$id);
            return $todo = $this->db->get('todos')->row_array();
        }

        function create($formArray){
            $this->db->insert('todos',$formArray);
        }

        function editTodo($id, $formArray){
            $this->db->where('id',$id);
            $this->db->update('todos',$formArray);
        }

        function deleteTodo($id){
            $this->db->where('id',$id);
            $this->db->delete('todos');
        }

        function fetch_data($query){
            $this->db->select("*");
            $this->db->from('todos');
            if($query != '')
            {
                $this->db->like('name',$query);
                $this->db->or_like('description',$query);
            }
            $this->db->order_by('id');
            return $this->db->get();
        }

    }