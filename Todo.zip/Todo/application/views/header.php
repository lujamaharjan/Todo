<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Todo List</title>
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap.min.css';?>">
   
</head>
<div class="navbar navbar-dark bg-dark">
        <div class="container">
            <a href="#" class="navbar-brand">Todo List</a>
        </div>
</div>

<body>
    
  