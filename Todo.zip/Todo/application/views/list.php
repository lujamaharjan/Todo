


<div class="container">
    <div class="row">
        <div class="col-md-12">
        <?php $success = $this->session->userdata('success'); 
                    if($success != ""){
                ?>
                <div class="alert alert-success"><?php echo $success;?></div>
                <?php   } ?>

                <?php $failure = $this->session->userdata('failure'); 
                    if($failure != ""){
                ?>
                <div class="alert alert-failure"><?php echo $failure;?></div>
                <?php   } ?>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-md-4">
            <h3>List of Todos</h3>
        </div>
        <div class="col-md-4 text-right">
            <form id="submit" method="post">
                <div class="input-group">
                    <input type="text" name="search"  id="search" placeholder="search" class="form-control">
                </div>
            </form>
        </div>
        <div class="col-md-4 text-right">
            <a class="btn  btn-block btn-primary " href="<?php echo base_url().'todo/create/';?>"> + Create</a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12" id="todoData">
        <table class="table table-striped" >
                <tr>
                    <th>S.N</th>
                    <th>Todo Name </th>
                    <th></th>
                </tr>
                <?php if(!empty($todos))  {
                    $i=1;   
                    foreach($todos as $todo)
                    {?>
                        <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $todo['name'];?></td>
                        <td><a href="<?php echo base_url().'todo/details/'.$todo['id'];?>" class="btn btn-primary">Details</a></td>
                        </tr>
                    <?php $i++;?>
                    <?php  } } else { ?>
                        <tr>
                        <td colspan="5"><p>No Tasks left! </p><td>
                        </tr>
                    <?php } ?>
            </table>
        </div>
    </div>
</div>

