    <script src="<?php echo base_url().'assets/js/jquery.min.js'; ?>"></script>
    <script src="<?php echo base_url().'assets/js/bootstrap.min.js';?>"></script>
</body>
</html>