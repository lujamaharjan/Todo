<div class="container">
    <h3>Edit User</h3>
    <div class="row">
        <div class="col-md-8">
            <form method="post" action="<?php echo base_url(). './todo/edit/'.$todo['id'];?>">
            <div class="form-group">
                        <label for="name">Todo Name</label>
                        <input type="text" name="name" value="<?php echo set_value('name',$todo['name']); ?>" class="form-control">
                        <?php echo form_error('name');?>
                    </div>
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea type="text"  name="description"  class="form-control"><?php echo set_value('description',$todo['description']); ?></textarea>
                        <?php echo form_error('description');?>
                    </div>
                    <button class="btn btn-primary">Update</button>
                    <a href="<?php echo base_url().'todo/';?>" class="btn btn-warning">Cancel</a>
            </form>
        </div>
    </div>
</div>