
<div class="container">
    <div class="jumbotron mt-5">
        <div class="head">
            
            <h3 ><?php echo $todo['name']; ?> </h3>
        </div>

        <div class="body">
        <h5>Details</h5>
            <p class="lead"><?php echo $todo['description']; ?></p>
        <h6>Created date: <span style="font-size:10px;"><?php echo $todo['date'];?></span></h6>
        <a href="<?php echo base_url().'todo/edit/'.$todo['id'];?>" class="btn btn-primary">Edit</a>
        <a href="<?php echo base_url().'todo/delete/'.$todo['id'];?>" class="btn btn-danger">Delete</a>
        <a href="<?php echo base_url().'todo/';?>" class="btn btn-secondary">Back</a>
        </div>
    </div>
</div>